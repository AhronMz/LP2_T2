package com.examenT2.LP2_T2_MezaDavid.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.hibernate.annotations.DynamicInsert;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "tbl_orden_compra")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@DynamicInsert
public class OrdenCompraMezaDavid {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "nro_orden")
	private Integer nroOrden;

	@Column(name = "monto")
	private BigDecimal monto;

	@Column(name = "direccion_entrega")
	private String direccionEntrega;

	@Column(name = "fecha_entrega")
	private LocalDate fechaEntrega;

	@Column(name = "estado")
	private String estado;

	@JoinColumn(name = "id_proveedor")
	@ManyToOne
	private ProveedorMezaDavid proveedor;

	public String getEstadoTexto() {
		if ("P".equalsIgnoreCase(estado)) {
			return "Pendiente";
		} else if ("C".equalsIgnoreCase(estado)) {
			return "Completado";
		} else {
			return "Anulado";
		}
	}
}
